package com.example.onetonline.presentation.model;

public class GameBoardState {
}
