package com.example.onetonline.presentation.view;

public interface WellComeScreenView {
    void navigateTo(Class<?> avtivityClass);
}
