package com.example.onetonline.presentation.view;

public interface GamePlayView {
    void onButtonXClick();
    void onButtonSearchClick();
    void onButtonSwitchClick();
}
