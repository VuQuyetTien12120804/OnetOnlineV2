package com.example.onetonline.presentation;

import android.content.Context;

public class CustomToast {
    public static void show(Context context, String message){

    }
}
