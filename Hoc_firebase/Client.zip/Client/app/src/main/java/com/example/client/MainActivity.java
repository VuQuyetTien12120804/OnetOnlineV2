package com.example.client;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {
    String serverIP = "192.168.1.95"; // Đặt IP của Server
    int port = 9999;
    Socket socket;
    PrintWriter output;
    BufferedReader input;
    TextView txtMessage;
    EditText edtMessage;
    Button btnSend;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtMessage = findViewById(R.id.txtMessage);
        edtMessage = findViewById(R.id.edtMessage);
        btnSend = findViewById(R.id.btnSend);

        new Thread(() -> {
            try {
                socket = new Socket(serverIP, port);
                output = new PrintWriter(socket.getOutputStream(), true);
                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                String message;
                while ((message = input.readLine()) != null) {
                    String finalMessage = message;
                    runOnUiThread(() -> txtMessage.append("Server: " + finalMessage + "\n"));
                }
            } catch (Exception e) {
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(this, "Kết nối thất bại", Toast.LENGTH_SHORT).show());
            }
        }).start();

        btnSend.setOnClickListener(v -> {
            String message = edtMessage.getText().toString();
            if (!message.isEmpty()) {
                output.println(message);
                txtMessage.append("Client: " + message + "\n");
                edtMessage.setText("");
            }
        });
    }
}
